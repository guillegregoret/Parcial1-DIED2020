import java.util.ArrayList;
import java.util.Date;

public abstract class Empleado {
	private Integer cuil;
	private Date fecha_nacimiento;
	private String mail;
	private ArrayList<Venta> lista_venta;
	public Integer getCuil() {
		return cuil;
	}
	public void setCuil(Integer cuil) {
		this.cuil = cuil;
	}
	public Date getFecha_nacimiento() {
		return fecha_nacimiento;
	}
	public void setFecha_nacimiento(Date fecha_nacimiento) {
		this.fecha_nacimiento = fecha_nacimiento;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public ArrayList<Venta> getLista_venta() {
		return lista_venta;
	}
	public void setLista_venta(ArrayList<Venta> lista_venta) {
		this.lista_venta = lista_venta;
	}
}
