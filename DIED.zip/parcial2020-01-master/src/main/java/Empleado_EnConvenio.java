
public class Empleado_EnConvenio extends Empleado{
	private Integer antiguedad;
	public Integer getAntiguedad() {
		return antiguedad;
	}
	public void setAntiguedad(Integer antiguedad) {
		this.antiguedad = antiguedad;
	}
	public Double getSueldo_basico() {
		return sueldo_basico;
	}
	public void setSueldo_basico(Double sueldo_basico) {
		this.sueldo_basico = sueldo_basico;
	}
	private Double sueldo_basico;
}
