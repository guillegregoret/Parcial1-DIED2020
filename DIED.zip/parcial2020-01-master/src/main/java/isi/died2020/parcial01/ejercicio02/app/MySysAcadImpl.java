package isi.died2020.parcial01.ejercicio02.app;

import java.util.ArrayList;
import java.util.List;

import isi.died2020.parcial01.ejercicio02.db.BaseDeDatos;
import isi.died2020.parcial01.ejercicio02.db.BaseDeDatosExcepcion;
import isi.died2020.parcial01.ejercicio02.dominio.*;
import isi.died2020.parcial01.ejercicio02.dominio.Docente.Cargo;


public class MySysAcadImpl implements MySysAcad {
	private static final BaseDeDatos DB = new BaseDeDatos();
	private final static Integer max_examenes_mes = 6;  

	private List<Materia> materia = new ArrayList<Materia>();
	
	@Override
	public void registrarMateria(Materia d) {
		this.materia.add(d);
	}
	
	private List<Docente> docentes = new ArrayList<Docente>();
	
	@Override
	public void registrarDocente(Docente d) {
		this.docentes.add(d);
	}
	
	private List<Alumno> alumnos = new ArrayList<Alumno>();
	
	@Override
	public void registrarAlumnos(Alumno d) {
		this.alumnos.add(d);
	}
	

	@Override
	public void inscribirAlumnoCursada(Docente d, Alumno a, Materia m, Integer cicloLectivo) {
		Inscripcion insc = new Inscripcion(cicloLectivo,Inscripcion.Estado.CURSANDO);
		d.agregarInscripcion(insc);
		a.addCursada(insc);
		m.addInscripcion(insc);
		// DESCOMENTAR Y gestionar excepcion
		try {

			DB.guardar(insc);
		} catch (BaseDeDatosExcepcion e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void inscribirAlumnoExamen(Docente d, Alumno a, Materia m) {
		Examen e = new Examen();
		a.addExamen(e);
		d.agregarExamen(e);
		m.addExamen(e);
		// DESCOMENTAR Y gestionar excepcion
		try {
			if(d.getCargo()!=Cargo.PROFESOR && d.getCantExamenes()<MySysAcadImpl.max_examenes_mes) {
				throw new NoProfesor();
			}
			else {
				DB.guardar(e);
			}
	
		} catch (Exception e1) {
			
			e1.printStackTrace();
		}
	}
	public void registrarNota(Examen e, Integer n) {
		e.setNota(n);
		if(n>=6) {
			for (int i = 0; i < e.getAlumno().getMateriasCursadas().size(); i++) {
				for (int j = 0; j < e.getAlumno().getMateriasCursadas().get(i).getMateria().getExamenes().size(); j++) {
					if(e.getAlumno().getMateriasCursadas().get(i).getMateria().getExamenes().get(j).equals(e)) {
						for (int j2 = 0; j2 < e.getAlumno().getMateriasCursadas().get(i).getMateria().getInscripciones().size(); j2++) {
							if(e.getAlumno().getMateriasCursadas().get(i).getMateria().getInscripciones().get(j2).getInscripto().equals(e.getAlumno())) {
								e.getAlumno().getMateriasCursadas().get(i).getMateria().getInscripciones().get(j2).setEstado(Inscripcion.Estado.PROMOCIONADO);
								break;
							}
							
						}
						break;
					}
				}
			}
		}
	}
	

}
