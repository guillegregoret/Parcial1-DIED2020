package isi.died2020.parcial01.ejercicio02.app;

public class NoProfesor extends Exception {

	private static final long serialVersionUID = 1L;

	public NoProfesor() {
		super("No es profesor y no alcanzo el maximo de examenes en el mes");
	}
}
