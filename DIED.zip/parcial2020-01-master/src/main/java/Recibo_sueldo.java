
public class Recibo_sueldo {
	private Integer nro;
	private Integer nro_mes;
	private Double total_pago;
	private Empleado emp;
	public Integer getNro() {
		return nro;
	}
	public void setNro(Integer nro) {
		this.nro = nro;
	}
	public Integer getNro_mes() {
		return nro_mes;
	}
	public void setNro_mes(Integer nro_mes) {
		this.nro_mes = nro_mes;
	}
	public Double getTotal_pago() {
		return total_pago;
	}
	public void setTotal_pago(Double total_pago) {
		this.total_pago = total_pago;
	}
	public Empleado getEmp() {
		return emp;
	}
	public void setEmp(Empleado emp) {
		this.emp = emp;
	}
}
