import java.util.ArrayList;
import java.util.Calendar;

public class RRHH {
	private Integer valor_obj=5;
	ArrayList<Recibo_sueldo> Recibos_Sueldo(ArrayList<Empleado> emp){
		ArrayList<Recibo_sueldo> recibos = new ArrayList<Recibo_sueldo>(); 
		for (int i = 0; i < emp.size(); i++) {
			Recibo_sueldo rs = new Recibo_sueldo();
			if(emp.get(i) instanceof Empleado_Contratado) {
				Double tp;
				tp=(((Empleado_Contratado) emp.get(i)).getTotal_horas_trabajo()*((Empleado_Contratado) emp.get(i)).getCosto_hora());
				if(emp.get(i).getLista_venta().size()>valor_obj) {
					tp+=(((Empleado_Contratado) emp.get(i)).getCosto_hora())*5+emp.get(i).getLista_venta().size();
				}
				Calendar month = Calendar.getInstance();
				
				month.setTime(emp.get(i).getFecha_nacimiento());
				if(month.get(Calendar.MONTH)==Calendar.getInstance().get(Calendar.MONTH)){
					tp=tp*1.5;
				}
				rs.setTotal_pago(tp);
			}else {
				Double temp=0.0;
				Double tp=1.0;
				for (int j = 0; j < emp.get(i).getLista_venta().size(); j++) {
					temp+=emp.get(i).getLista_venta().get(j).getMonto_total(); //30%
				}
				Calendar month = Calendar.getInstance();
				
				month.setTime(emp.get(i).getFecha_nacimiento());
				if(month.get(Calendar.MONTH)==Calendar.getInstance().get(Calendar.MONTH)){
					tp=1.5;
				}
				
				rs.setTotal_pago((((Empleado_EnConvenio) emp.get(i)).getSueldo_basico()+temp*0.3)*(tp-0.14));
			}
			rs.setNro(4564564);
			rs.setEmp(emp.get(i));
			rs.setNro_mes(Calendar.getInstance().get(Calendar.MONTH));
			
			recibos.add(rs);
		}
		return recibos;
	}

}
