
public class Empleado_Contratado extends Empleado{
	private Integer total_horas_trabajo;
	private Double costo_hora;
	public Integer getTotal_horas_trabajo() {
		return total_horas_trabajo;
	}
	public void setTotal_horas_trabajo(Integer total_horas_trabajo) {
		this.total_horas_trabajo = total_horas_trabajo;
	}
	public Double getCosto_hora() {
		return costo_hora;
	}
	public void setCosto_hora(Double costo_hora) {
		this.costo_hora = costo_hora;
	}
	
}
