import java.util.Date;

public class Venta {
	private Integer nro_venta;
	public Integer getNro_venta() {
		return nro_venta;
	}
	public void setNro_venta(Integer nro_venta) {
		this.nro_venta = nro_venta;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public Double getMonto_total() {
		return monto_total;
	}
	public void setMonto_total(Double monto_total) {
		this.monto_total = monto_total;
	}
	private Date fecha;
	private Double monto_total;
}
